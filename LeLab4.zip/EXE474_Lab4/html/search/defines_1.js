var searchData=
[
  ['led_5fpin_0',['LED_PIN',['../_e_e474___lab4part1_8ino.html#ab4553be4db9860d940f81d7447173b2f',1,'EE474_Lab4part1.ino']]],
  ['light_5fsensor_5fpin_1',['LIGHT_SENSOR_PIN',['../_e_e474___lab4part2_8ino.html#adfd6a3f8aa3f1c719f648de4e3701fba',1,'EE474_Lab4part2.ino']]]
];
