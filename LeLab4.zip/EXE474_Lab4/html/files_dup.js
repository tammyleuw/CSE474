var files_dup =
[
    [ "EE474_Lab4part1.ino", "_e_e474___lab4part1_8ino.html", "_e_e474___lab4part1_8ino" ],
    [ "EE474_Lab4part2.ino", "_e_e474___lab4part2_8ino.html", "_e_e474___lab4part2_8ino" ]
];