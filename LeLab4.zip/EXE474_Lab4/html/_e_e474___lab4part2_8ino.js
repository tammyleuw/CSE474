var _e_e474___lab4part2_8ino =
[
    [ "BUZZER_PIN", "_e_e474___lab4part2_8ino.html#ab61d0981ed42df9e18211b273d22cfcd", null ],
    [ "LIGHT_SENSOR_PIN", "_e_e474___lab4part2_8ino.html#adfd6a3f8aa3f1c719f648de4e3701fba", null ],
    [ "anomalyAlarmTask", "_e_e474___lab4part2_8ino.html#a929ff1f234b1daf57efaebb75793c4f7", null ],
    [ "calculateSMA", "_e_e474___lab4part2_8ino.html#af021c555cb608a67ef72e390038d9428", null ],
    [ "lcd", "_e_e474___lab4part2_8ino.html#ae084e1bc8ccb35ea289ba0ca4972ea6d", null ],
    [ "lcdTask", "_e_e474___lab4part2_8ino.html#abc0a5e2b9db7d26f855df2e334fd4bda", null ],
    [ "lightDetectorTask", "_e_e474___lab4part2_8ino.html#ab8e13e31e625fec5c646fd7afd4b8c27", null ],
    [ "loop", "_e_e474___lab4part2_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "onTimer", "_e_e474___lab4part2_8ino.html#ada06ab1c4bbd307a9fea75726c8894f1", null ],
    [ "primeCalculationTask", "_e_e474___lab4part2_8ino.html#a64c67870c768d4e93f85219a5e8eb3b1", null ],
    [ "setup", "_e_e474___lab4part2_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "anomalyDetected", "_e_e474___lab4part2_8ino.html#a0a934593cadefaa512efb1b4fc9da343", null ],
    [ "buzzerCount", "_e_e474___lab4part2_8ino.html#a4c190c9f9fe83df16954b0bf9c29d526", null ],
    [ "lastsma", "_e_e474___lab4part2_8ino.html#ae18260f2af2db892e058ff575a06e744", null ],
    [ "lightLevel", "_e_e474___lab4part2_8ino.html#a2c8713f6d9ff943921e8b4693544f227", null ],
    [ "sma", "_e_e474___lab4part2_8ino.html#a0859ec777d38758a2d060698a412f688", null ],
    [ "smaIndex", "_e_e474___lab4part2_8ino.html#a8da6e8bbf7d43028a3bf855b8c3ff357", null ],
    [ "smaList", "_e_e474___lab4part2_8ino.html#af8e873a83111674ee40f280bdadf3aa1", null ],
    [ "timer", "_e_e474___lab4part2_8ino.html#a97222eeccb5b18e1fc532806c1efcb34", null ],
    [ "timerExpired", "_e_e474___lab4part2_8ino.html#af011873900e2dbaa77fb90b534494faa", null ],
    [ "xSemaphore", "_e_e474___lab4part2_8ino.html#a0639b448c4862618f597670523ef9975", null ]
];